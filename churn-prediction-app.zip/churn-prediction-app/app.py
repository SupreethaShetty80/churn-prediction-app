from flask import Flask, render_template, request, jsonify
import pandas as pd
import numpy as np
import joblib
import os

app = Flask(__name__)

model = joblib.load('model/churn_model.pkl')
label_encoders = joblib.load('model/label_encoders.pkl')
scaler = joblib.load('model/scaler.pkl')
feature_columns = joblib.load('model/feature_columns.pkl')

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    try:
        form_data = request.form
        
        input_data = {}
        
        categorical_features = ['gender', 'Partner', 'Dependents', 'PhoneService', 
                               'MultipleLines', 'InternetService', 'OnlineSecurity',
                               'OnlineBackup', 'DeviceProtection', 'TechSupport',
                               'StreamingTV', 'StreamingMovies', 'Contract',
                               'PaperlessBilling', 'PaymentMethod']
        
        numerical_features = ['SeniorCitizen', 'tenure', 'MonthlyCharges', 'TotalCharges']
        
        for feature in categorical_features:
            if feature in form_data:
                if feature in label_encoders:
                    input_data[feature] = label_encoders[feature].transform([form_data[feature]])[0]
                else:
                    input_data[feature] = 0  
            else:
                input_data[feature] = 0
        
        for feature in numerical_features:
            if feature in form_data and form_data[feature]:
                input_data[feature] = float(form_data[feature])
            else:
                input_data[feature] = 0.0
        
        input_df = pd.DataFrame([input_data])
        
        for col in feature_columns:
            if col not in input_df.columns:
                input_df[col] = 0
        
        input_df = input_df[feature_columns]
        
        numerical_indices = [i for i, col in enumerate(feature_columns) 
                           if col in numerical_features]
        input_df.iloc[:, numerical_indices] = scaler.transform(
            input_df.iloc[:, numerical_indices]
        )
        
        prediction = model.predict(input_df)[0]
        probability = model.predict_proba(input_df)[0]
        
        result = {
            'churn_prediction': 'Yes' if prediction == 1 else 'No',
            'churn_probability': float(probability[1]),
            'no_churn_probability': float(probability[0])
        }
        
        return render_template('result.html', result=result)
    
    except Exception as e:
        return render_template('result.html', 
                             result={'error': str(e)})

@app.route('/api/predict', methods=['POST'])
def api_predict():
    try:
        data = request.get_json()
        
       
        
        return jsonify({'prediction': 'success', 'data': data})
    
    except Exception as e:
        return jsonify({'error': str(e)})

if __name__ == '__main__':
    app.run(debug=True)