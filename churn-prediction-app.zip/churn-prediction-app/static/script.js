// Form validation
document.getElementById('prediction-form').addEventListener('submit', function(e) {
    const tenure = document.getElementById('tenure').value;
    const monthlyCharges = document.getElementById('MonthlyCharges').value;
    const totalCharges = document.getElementById('TotalCharges').value;
    
    if (tenure < 0 || tenure > 100) {
        e.preventDefault();
        alert('Please enter a valid tenure between 0 and 100 months');
        return;
    }
    
    if (monthlyCharges < 0 || monthlyCharges > 200) {
        e.preventDefault();
        alert('Please enter valid monthly charges between $0 and $200');
        return;
    }
    
    if (totalCharges < 0) {
        e.preventDefault();
        alert('Please enter valid total charges');
        return;
    }

    // Show loading overlay instead of changing button text
    document.getElementById('loading').classList.add('active');
});

// Auto-calculate total charges
document.getElementById('MonthlyCharges').addEventListener('input', calculateTotalCharges);
document.getElementById('tenure').addEventListener('input', calculateTotalCharges);

function calculateTotalCharges() {
    const monthlyCharges = parseFloat(document.getElementById('MonthlyCharges').value) || 0;
    const tenure = parseFloat(document.getElementById('tenure').value) || 0;
    
    if (monthlyCharges > 0 && tenure > 0) {
        const estimatedTotal = monthlyCharges * tenure;
        document.getElementById('TotalCharges').value = estimatedTotal.toFixed(2);
    }
}

// Optional: Add reset functionality
document.querySelector('button[type="reset"]').addEventListener('click', function() {
    // Clear all form fields
    document.getElementById('prediction-form').reset();
    // Reset total charges field
    document.getElementById('TotalCharges').value = '';
});

// Add smooth hover effects (optional)
document.querySelectorAll('.form-group').forEach(group => {
    group.addEventListener('mouseenter', function() {
        this.style.transform = 'translateY(-2px)';
    });
    group.addEventListener('mouseleave', function() {
        this.style.transform = 'translateY(0)';
    });
});